# Exercises for QGIS and R workshop, NHM 21 May 2025
# Developed from exercises in BIOS 5211/9211 by
# Olav Skarpaas, Eva Lieungh, Peter Horvath, Erik Kusch and Dag Endresen
# NHM, University of Oslo


# Preparations:
# Download and install R: https://cran.r-project.org/
# Download and install R studio: https://www.rstudio.com/
# Open R studio and start a new project
# Download Lab material from github and put in your R project folder
# Download and install packages:
# install.packages(c("raster", "fields"))


#########################
# Exercise 1: A DM primer
#########################

# In this exercise we will run quickly through the steps in distribution modelling
# from a ready-made training data set to model output and map predictions.
# WARNING! This exerceise neither demonstrates all aspects of good modelling practice,
# nor great models - it is just a quick and simple start.

# Load packages
library(raster) # for raster data tools - NB! this package has been superseded by 'terra'
library(fields) # for tim.colors and other color palettes

# Load training data
# This is a pre-made data set, in Exercise 2 we will make one
load("DM_primer_training_data")

# View top and bottom of data
head(training_data)
tail(training_data)

# Load predictor variable data (temperature)
temp <- raster("DM_primer_predictor_map")

# Plot predictor map (temperature)
plot(temp)

# Plot observations on predictor map
presence_points <- training_data[training_data$presence==1, c("x","y")]
points(presence_points)
absence_points <- training_data[training_data$presence==0, c("x","y")]
points(absence_points,pch="+",col="red")

# Fit a first regression model to training data using GLM
m1 <- glm(presence~temp,family=binomial,data=training_data)

# Inspect model - what are the null and alternative hypotheses?
summary(m1)

# Make map of predictions - how does the species respond?
p1 <- predict(temp,m1,type="response")
plot(p1)

# Put plots on the same page, with headers and different colors for predicted probabilities of presence
par(mfrow=c(3,1),mar=c(2,2,4,5)+0.1) # make space for 3 rows of plots, specify plot margins
plot(temp,main="Temperature")
points(presence_points)
points(absence_points,pch="+",col="red")
plot(p1,col=tim.colors(64),main="Probability of presence - model 1")

# A better model, plotted below the first one
m2 <- glm(presence~temp+I(temp^2),family=binomial,data=training_data) # I() makes R treat temp^2 as a polynomial rather than an interaction term
p2 <- predict(temp,m2,type="response")
plot(p2,col=tim.colors(64),main="Probability of presence - model 2")

# Inspect model 2 and compare to model 1
summary(m2)

# Interpret and discuss the models. The species is Picea sitchensis (Sitka spruce, sitkagran).
# How does the species respond to the predictors?
# How do model predictions compare to the data?
# Search for Picea sitchensis on gbif.org. How do model predictions compare to all observations in GBIF?
# Are responses and predictions in accordance with ecological expectations for this species?
# What could be done to improve the models and predictions?



###################################################################
# Exercise 2: Connecting species occurrences and environmental data
###################################################################

# Libraries: spatial data tools
# we show you a different way of handling package installation of loading in one step here:
install.load.package <- function(x) { # custom function that loads the desired package and automatically installs any non-installed packages
  if (!require(x, character.only = TRUE))
    install.packages(x, repos='http://cran.us.r-project.org')
  require(x, character.only = TRUE)
}
package_vec <- c( # vector of package names
  "rgbif",      # global biodiversity data (GBIF) tools
  "maps",       # Provides functions that let us plot the maps
  "mapdata",    # Contains the hi-resolution points that mark out the countries.require(maps)
  "mapproj",
  "maptools" # mapping tools for spatial objects
)
sapply(package_vec, install.load.package) # applying install/load function to each name in package vector


# Handling Raster Data
# Loading a raster data set for Norway
# This method loads several files at once,
# and keeps file names as variable names:
path <- "RASTER/10km"
r.list <- list.files(path, pattern="tif$", full.names=TRUE) # add all raster files in a given folder to a list
predictors <- stack(r.list)                                 # read and stack raster layers
names(predictors)

# Make background raster for Norway
norway <- predictors$dem100_10km/predictors$dem100_10km     # raster with values=1 in mainland Norway, based on elevation raster
plot(norway)


# GBIF occurrence data
# The approach below gives quick access to data sets of limited size, suitable
# for our purpose in this course.
# However, for scientific publications you should use asynchronous downloading,
# as demonstrated here 
# Erik Kusch: https://www.erikkusch.com/courses/gbif/
# by Anders Finstad in a workshop at the Nordic Oikos conference:
# https://gbif-europe.github.io/nordic_oikos_2018_r/s3_gbif_demo/3.x_async_download_gbif.Rmd
# This allows downloading larger data sets, and citation of a download with a single doi.

# GBIF Data discovery
# first, we figure out how GBIF indexes the species we are interested in:
key <- name_backbone(name="Picea sitchensis", kingdom="Plantae")$speciesKey
key

# Data download
# next, we query retrieval of 1000 observation of our target species within Norway
sp <- occ_search(taxonKey=key, # which species we want
                 hasCoordinate=TRUE, # whether data should be geo-referenced
                 country="NO", # what country the data should come from, these are ALPHA-2 ISO country codes: https://www.nationsonline.org/oneworld/country_code_list.htm
                 limit=1000 # how many observations to retrieve at most
) 
#' NOTICE: do NOT use this function for your actual research!! See instructions by Erik Kusch and Anders Finstad above

# data sources GBIF has used for your download:
gbif_citation(sp)                # Overview of data sources with references, including doi. See https://www.gbif.org/tool/81747/rgbif#citations


### Occurrence data handling
# Convert lat-long coordinates to coordinate system of environmental raster data
occ_points <- data.frame(x=sp$data$decimalLongitude,y=sp$data$decimalLatitude) # extract coordinates
occ_points <- SpatialPoints(occ_points,proj4string=CRS("+proj=longlat +datum=WGS84")) # make spatial points, CRS is WGS84 because that is how GBIF records the data
occ_UTM33 <- spTransform(occ_points,CRS("+proj=utm +zone=33 ellps=GRS80 +units=m")) # transform to UTM CRS
sp$data$x <- occ_UTM33$x
sp$data$y <- occ_UTM33$y

# Point data like 'sp' can be used directly as input to some methods (e.g. maxent, as
# implemented in 'MIAmaxent'), along with environmental rasters.
# For glm and several other methods, we need absence data in addition to presences,
# and we need to combine presences and absences with environmental data in a
# data set suitable for the glm function. This can be done as follows.

# Rasterize occurrences
occ_ras <- rasterize(occ_UTM33,norway,fun='count',background=0)   # raster with counts of occurrences in each cell of norway
plot(occ_ras)
occ_ras <- occ_ras*norway                                         # filtering occurrence raster with mainland raster
occ_ras[occ_ras>0] <- 1                                           # reducing counts>0 to 1 (presence)
plot(occ_ras)
plot(occ_ras, xlim = c(-74000,10000), ylim = c(6610000, 6680000)) # zoom to western Norway to see the rasterized presence pixels
summary(occ_ras)
table(values(occ_ras))

# Take the occurrence cells as presences
presences <- which(values(occ_ras)==1)

# Then generate absence data by sampling from the cells without occurrence observations.
# NB! This rests on risky assumptions, but we need the absences
# for logistic regression with glm. We make this absence data set for
# educational purposes, but ideally one would want a data set with true, verified presences
# and absences for logistic regression (and also for validation of 'presence-only' methods,
# such as maxent).
absences <- which(values(occ_ras)==0)
absences_sample <- sample(absences,size=length(presences)) # sample of same number of absence cells as presence cells


### Extracting Environmental Data to match GBIF Data
# Combine presences, absences and environmental data
selected <- c(presences,absences_sample)
xy <- coordinates(occ_ras)[selected, ]
training_data <- data.frame(xy,presence=values(occ_ras)[selected],
                            extract(predictors,xy))
head(training_data)
tail(training_data)
plot(training_data[,c("x","y")],col=c("blue","red")[training_data$presence+1])

# Convert discrete environmental predictors to factor variables
training_data$ar50_artype_10km <- factor(training_data$ar50_artype_10km)
training_data$geo_norge123_10km <- factor(training_data$geo_norge123_10km)

# Save data (you'll overwrite any existing files with these names if you run these lines)
save(training_data,file="Norway_sitka_training_data")
save(predictors,file="Norway_predictor_raster_stack")



#####################################################
# Exercise 3: Make a model for sitka spruce in Norway
#####################################################

# A. Use code from exercise 1 and data from exercise 2 and make a model for
# sitka spruce in Norway. Replace temperature ('temp') with other predictors
# as you see fit

# B. Then make similar models with other methods and functions in
# other libraries, such as the 'sdm' library
install.packages("sdm")
library(sdm)
?sdm



######################################################################
# Exercise 4: Download data for your favorite species and make a model
######################################################################

# Reuse and modify code from previous exercises to make a data set and model
# for a species of your own choice.
# If the species is found in mainland Norway, you can reuse predictors from
# exercise 2; otherwise you may want to download other environmental data,
# such as worldclim: https://www.worldclim.org/data/bioclim.html



##################################
# Exercise 5: Watch a presentation
##################################

# Here's a link for inspiration and further independent study:
# GIS with R (ctrl+click) https://pakillo.github.io/GISwithR/GISwithR.html
